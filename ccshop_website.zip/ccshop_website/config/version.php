<?php

return array(

    'DR_UPDATE'		=> '2017.7.1',
    'DR_VERSION'	=> '5.0.9',
);
